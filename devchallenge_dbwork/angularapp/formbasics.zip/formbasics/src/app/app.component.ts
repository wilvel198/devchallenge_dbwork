import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormPoster } from './services/form-poster.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  languages = ['PUG-->ID----->https://media0.giphy.com/media/JfDNFU1qOZna/200_d.gif', 'Spanish'];

  searchResults = ['test'];
  primaryLanguages = '';
  readgiffy = 'hidden';
  hideElement = false;
  hideSearch = true;
  gifID = 'wil1';
  currentUser = 'w_velasquezcorp@yahoo.com';
  searchTopic = '';
  video = 'https://media0.giphy.com/media/JfDNFU1qOZna/200_d.gif';

  constructor ( private formPoster: FormPoster) {

    /*
    this.formPoster.getLanguages()
    .subscribe(
     data => this.languages = data,
     err => console.log('error', err));*/
  }
  model = new Employee('Darla', 'Smith', '1234 Somewhere',
  'Austin', 'Texas', 'w_velasquezcorp@yahoo.com', '78665', '512-555-5555', 'person198', 'password');

  submitForm(form: NgForm) {
    console.log(form.value);
    this.formPoster.postEmployeeForm(this.model)
    .subscribe(
    data => console.log('success', data),
    err => console.log('error', err));
  }

  submitSearchTopic(form: NgForm) {
   console.log('------------>' + form.control.get('searchTopic').value);
   console.log(form.value);
   this.searchTopic = form.control.get('searchTopic').value;


   this.formPoster.postGetSearchResults(this.searchTopic)
   .subscribe(
    data => this.searchResults = data,
    err => console.log('error', err));

  }

  selectedItemChanged() {
    console.log('search select has change');

  }


  checkFormInfo(form: NgForm) {
    console.log('checking the form');

  }
  getItemDetails(form: NgForm) {
   console.log('--------> Load Item Details');
   this.gifID = 'ID for Item';
   this.video = 'https://media0.giphy.com/media/fItgT774J3nWw/200_s.gif';
  }

  checkFormInfo2(form: NgForm) {
    console.log('button clicked from form 2');
    console.log(form.value);
    this.hideElement = false;
    this.gifID = 'ID-55555';
    console.log(form.controls['primaryLanguage'].value);
    console.log(form.controls['primaryLanguage'].value);

    this.formPoster.getLanguages()
    .subscribe(
     data => this.languages = data,
     err => console.log('error', err));

  }


}
export class Employee {
constructor(
  public firstName: string,
  public lastName: string,
  public address: string,
  public city: string,
  public state: string,
  public emailaddress: string,
  public zip: string,
  public phoneNumber: string,
  public username: string,
  public password: string,

 ) {}




}


