import { Injectable } from '@angular/core';
import { Employee } from '../models/employee.models';
import { Http } from '@angular/http';
import { Response, Headers, RequestOptions } from '@angular/http';


import { Observable} from 'rxjs';

import 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/delay';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { GiphyData } from 'src/app/app.component';

@Injectable()
export class FormPoster {
constructor(private http: Http) {}

private extractData(res: Response) {
const body = res.json();
console.log('returned statement -->' + JSON.stringify(body));
return body.fields || { };

}

private extractLanguages(res: Response) {
    const body = res.json();
    console.log('returned statement -->' + body);
    console.log('get array ' + body.languages);
    return body.languages || {};
}

private extractsearchResults(res: Response) {
    const body = res.json();
    console.log('returned statement -->' + body);
    console.log('get array ' + body.searchResults);
    return body.searchResults || {};
}

private extractIDResults(res: Response) {
    console.log('++++++++++++==**************++++++++++++++');
    const body = res.json();
    console.log('items --------->' + body);

    const giffyObj = <GiphyData>body;

    console.log('my fields value is ===>' + giffyObj.giffyId.valueOf());
    return body;

}

private extractLoginResults(res: Response) {
    console.log('------------> return msg <--------');
    const body = res.json();
    return body;
}

private handleError(error: any) {
  console.error('post error:' + error);
  return Observable.throw(error.statusText);
}

postEmployeeForm(employee: Employee): Observable<any> {
    const body = JSON.stringify(employee);
    const headers = new Headers({'Content-Type': 'application/json'});
    const options = new RequestOptions({ headers : headers});

    return this.http.post('http://localhost:8080/createUser', body, options)
    .map(this.extractData)
    .catch(this.handleError);
}



postLoginRequest(loginJson: string): Observable<any> {
console.log('-----------------------');
console.log(loginJson);

const headers = new Headers({'Content-Type': 'application/json'});
const options = new RequestOptions({ headers : headers});
return this.http.post('http://localhost:8080/login', loginJson, options)
.map(this.extractLoginResults)
.catch(this.handleError);

}

postGetItemDetails(searchTopic: string): Observable<any> {
console.log('************************');
console.log('get searchTopic by ID');


const body = '{"searchTopic":"' + searchTopic + '"}';
const headers = new Headers({'Content-Type': 'application/json'});
const options = new RequestOptions({ headers : headers});
return this.http.post('http://localhost:8080/searchByID', body, options)
.map(this.extractIDResults)
.catch(this.handleError);
}


postGetSearchResults(searchTopic: string): Observable<any> {
    console.log('get searchTopic');
    console.log('search string -->' + searchTopic);

    const body = '{"searchTopic":"' + searchTopic + '"}';
    const headers = new Headers({'Content-Type': 'application/json'});
    const options = new RequestOptions({ headers : headers});
    return this.http.post('http://localhost:8080/searchByTopic', body, options)
    .map(this.extractsearchResults)
    .catch(this.handleError);

}
getLanguages(): Observable<any> {
return this.http.get('http://localhost:8080/getLanguages')
.delay(5000)
.map(this.extractLanguages)
.catch(this.handleError);

}

}
