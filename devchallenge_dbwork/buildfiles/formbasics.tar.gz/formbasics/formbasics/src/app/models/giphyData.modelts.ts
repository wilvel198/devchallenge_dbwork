export class GiphyData {
    constructor(
      public giffyId: string,
      public giffyTitle: string,
      public giffyURL: string,
      public giffyEmbeddedURL: string
     ) { }
    }
