
export class Employee {
    constructor(
      public firstName: string,
      public lastName: string,
      public city: string,
      public state: string,
      public emailaddress: string,
      public username: string,
      public password: string
     ) { }
    }
