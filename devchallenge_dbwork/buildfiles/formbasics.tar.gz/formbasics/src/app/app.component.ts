import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormPoster } from './services/form-poster.service';
import { NgForm } from '@angular/forms';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { SafeStyle } from '@angular/platform-browser/src/security/dom_sanitization_service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']

})
export class AppComponent {
  languages = ['PUG-->ID----->https://media0.giphy.com/media/JfDNFU1qOZna/200_d.gif', 'Spanish'];

  searchResults = [''];
  primaryLanguages = '';
  readgiffy = 'hidden';
  hideElement = false;


  gifID = '';
  currentUser = '';
  searchTopic = '';
  video = 'https://media0.giphy.com/media/JfDNFU1qOZna/200_d.gif';
  giffyId = '';
  giffyTitle = '';
  giffyURL = '';
  giffyEmbededURL = '';
  singleItemTopic = '';
  loginusername = '';
  loginpassword = '';
  mainPageTitle = 'Search';
  returnMsg = '';

  hideLoginPage = false;
  hideAccountCreation = true;
  hideSearch = true;


  sanURL = '';
  public image: SafeStyle;
  giffyData = new GiphyData('wil', 'test', 'test1', 'test3');
  iframe = 'https://www.google.com';


  constructor ( private formPoster: FormPoster, private _sanitizer: DomSanitizer) {
  const giffyItems = new GiphyData('', '', '', '');

    /*
    this.formPoster.getLanguages()
    .subscribe(
     data => this.languages = data,
     err => console.log('error', err));*/
  }
  model = new Employee('Darla', 'Smith', '1234 Somewhere',
  'Austin', 'Texas', 'w_velasquezcorp@yahoo.com', '78665', '512-555-5555', 'person198', 'password');

  giphyData = new GiphyData('check', 'two', 'one', 'zero');
  submitForm(form: NgForm) {
    console.log(form.value);
    this.formPoster.postEmployeeForm(this.model)
    .subscribe(
    data => console.log('success', data),
    err => console.log('error', err));
    console.log('switch screens');
    alert('account created succesfully - login now');
    this.hideLoginPage = false;
    this.hideAccountCreation = true;
  }


  submitSearchTopic(form: NgForm) {
   console.log('------------>' + form.control.get('searchTopic').value);
   console.log(form.value);
   this.searchTopic = form.control.get('searchTopic').value;
   this.mainPageTitle = 'Search';
    console.log('-->clear the fields before searching<--');

   this.formPoster.postGetSearchResults(this.searchTopic)
   .subscribe(
    data => this.searchResults = data,
    err => console.log('error', err));

  }
  callLogin(form: NgForm) {
    console.log(form.value);
    const localUsrname = form.control.get('loginuserame').value;
    const localPwd = form.control.get('loginpassword').value;
    const postJson = '{"type": "login","username":"' + localUsrname  + '","password":"' + localPwd  + '"}';
    console.log('user name --> ' + localUsrname);

    this.formPoster.postLoginRequest(postJson)
    .subscribe(
      data => {
      console.log(JSON.stringify(data));
      const loginObj = <LoginData>data;
      const status = loginObj.status.valueOf();
      const localMsg = loginObj.msg.valueOf();
      console.log('USER EMAIL --> ' + loginObj.objectType.valueOf());
      if ( status === 'active' ) {
        console.log('user succesfully authenticated');
        this.currentUser = loginObj.objectType.valueOf();
        this.hideSearch = false;
        this.hideLoginPage = true;
    } else {
        this.returnMsg = localMsg;
    }
      }

    );


  }




  selectedItemChanged() {
    console.log('search select has change');

  }


  checkFormInfo(form: NgForm) {
    console.log('checking the form');

  }

  getItemsFromSearch(form: NgForm) {
  console.log('------------>>>>>> GETTTING ITEMS FROM SEARCH<<<<<<<<<<----');
  console.log(JSON.stringify(this.getItemDetails(form)));

  }
  getItemDetails(form: NgForm) {
   console.log('--------> Load Item Details');
   if ( this.mainPageTitle === 'Favorites') {
    console.log('split the fields and add favorite items to field');
   }
   this.gifID = 'ID for Item';
   this.video = '';
   this.singleItemTopic = form.controls['primaryLanguage'].value;
    console.log('call get item detail function and send '  + this.singleItemTopic);


    this.formPoster.postGetItemDetails(this.singleItemTopic)
   .subscribe(
    data => {
      const giffyObj = <GiphyData>data;
      console.log('Giffy ID ' + giffyObj.giffyId.valueOf());
      this.gifID = giffyObj.giffyId.valueOf();
      this.giffyTitle = giffyObj.giffyTitle.valueOf();
      this.giffyEmbededURL = giffyObj.giffyEmbeddedURL.valueOf();
      this.giffyURL = giffyObj.giffyURL.valueOf().toString();
      this.video = giffyObj.giffyURL.valueOf();
    } ,
    err => console.log('error', err));
    console.log('**************** start mpow **************');
    console.log(JSON.stringify(this.giffyData));

    console.log('**************** end **************');

  }

  public getSantizeUrl(url: string) {
    return this._sanitizer.bypassSecurityTrustUrl(url);
}

  assembleHTMLItem(url: String) {
    const strHTML = '<img src>';
    return this._sanitizer.bypassSecurityTrustHtml(strHTML);
  }

  getSafeUrl() {
    console.log('gettin safe url');
    console.log(this.video);
    console.log(this._sanitizer.bypassSecurityTrustResourceUrl(this.video));
    return this._sanitizer.bypassSecurityTrustResourceUrl(this.video);
}

openRegistration() {
console.log('open registration form');
this.hideLoginPage = true;
this.hideAccountCreation = false;

}
  checkFormInfo2(form: NgForm) {
    console.log('button clicked from form 2');
    console.log(form.value);
    this.hideElement = false;
    this.gifID = 'ID-55555';
    console.log(form.controls['primaryLanguage'].value);
    console.log(form.controls['primaryLanguage'].value);

    this.formPoster.getLanguages()
    .subscribe(
     data => this.languages = data,
     err => console.log('error', err));

  }

  addtoFavorites(form: NgForm) {
    console.log('--------adding to favorites -----------');
    const giffySaveObj = new GiffySaveObject('' , '' , '' , '', '' , '');
    const userAccount = this.currentUser;
    const localGiphyID = this.gifID;
    const localGiphyURL = this.giffyURL;
    const localEmbURL = this.giffyEmbededURL;
    const localTitle = this.giffyTitle;
    const localCat = form.controls['categories'].value;
    console.log('current user sesssion---->'  + userAccount);
    console.log('giphy ID ----> ' + localGiphyID);
    console.log('categories -->' + localCat);

    giffySaveObj.emailAddress = userAccount;
    giffySaveObj.giffyTitle = localTitle;
    giffySaveObj.giffyID = localGiphyID;
    giffySaveObj.giffyURL = localGiphyURL;
    giffySaveObj.giffyEmbeddedURL = localEmbURL;
    giffySaveObj.categories = localCat;

    const myFavJson = JSON.stringify( giffySaveObj );
    console.log(JSON.stringify(giffySaveObj));

    this.formPoster.postFavorites(myFavJson)
   .subscribe(
    data => { console.log(JSON.stringify(data));
    } ,
    err => console.log('error', err));

  }

  getMyFavorites(form: NgForm) {
 console.log('--------> load my favotires <---------');
 this.mainPageTitle = 'Favorites';
 this.searchResults = [''];
 this.searchTopic = '';

 console.log('current user ' + this.currentUser);
  const searchString = '{"searchTopic":"' + this.currentUser  + '"}';

  this.formPoster.getUserFavorites(this.currentUser)
   .subscribe(
    data => this.searchResults = data,
    err => console.log('error', err));

  }

}
export class Employee {
constructor(
  public firstName: string,
  public lastName: string,
  public address: string,
  public city: string,
  public state: string,
  public emailaddress: string,
  public zip: string,
  public phoneNumber: string,
  public username: string,
  public password: string,

 ) {}




}

export class GiphyData {
  constructor(
    public giffyId: string,
    public giffyTitle: string,
    public giffyURL: string,
    public giffyEmbeddedURL: string
   ) { }
  }

  export class LoginData {
    constructor(
      public status: string,
      public msg: string,
      public objectType: string
    ) { }
  }

  export class GiffySaveObject {
    constructor(
      public emailAddress: string,
      public giffyTitle: string,
      public giffyID: string,
      public giffyURL: string,
      public giffyEmbeddedURL: string,
      public categories: string
    ) {}

  }


